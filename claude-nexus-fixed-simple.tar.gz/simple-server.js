// 简单的 Node.js 服务器替代 Cloudflare Workers dev
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8787;

const server = http.createServer((req, res) => {
  // CORS 头
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const url = req.url;
  
  // API 健康检查
  if (url === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'OK', timestamp: new Date().toISOString() }));
    return;
  }
  
  // API 根路径
  if (url.startsWith('/api/')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      message: 'Claude Code Nexus API', 
      version: '0.1.0',
      endpoints: ['/api/health'] 
    }));
    return;
  }
  
  // 静态文件服务
  let filePath = path.join(__dirname, 'dist/client', url === '/' ? 'index.html' : url);
  
  // 检查文件是否存在
  if (!fs.existsSync(filePath)) {
    // 如果是 SPA 路由，返回 index.html
    if (!url.includes('.') && !url.startsWith('/api/')) {
      filePath = path.join(__dirname, 'dist/client/index.html');
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
  }
  
  const ext = path.extname(filePath);
  const contentType = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  }[ext] || 'text/plain';
  
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500);
      res.end('Server Error');
      return;
    }
    
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Claude Code Nexus server running on http://0.0.0.0:${PORT}`);
  console.log(`📍 Health check: http://0.0.0.0:${PORT}/api/health`);
});